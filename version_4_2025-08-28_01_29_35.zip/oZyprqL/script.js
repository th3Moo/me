document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    const elements = {
        loginView: document.getElementById('login-view'),
        dashboardView: document.getElementById('dashboard-view'),
        loginForm: document.getElementById('login-form'),
        loginError: document.getElementById('login-error'),
        logoutBtn: document.getElementById('logout-btn'),
        navLinks: document.querySelectorAll('.nav-link'),
        pageTitle: document.getElementById('page-title'),
        pageContent: document.getElementById('page-content'),
        modal: document.getElementById('modal'),
        modalBackdrop: document.getElementById('modal-backdrop'),
        modalTitle: document.getElementById('modal-title'),
        modalBody: document.getElementById('modal-body'),
        modalFooter: document.getElementById('modal-footer'),
        modalCloseBtn: document.getElementById('modal-close-btn'),
    };

    const state = {
        currentFilters: {},
    };

    const checkAuth = () => {
        const token = localStorage.getItem('adminAuthToken');
        if (token) {
            showDashboard();
        } else {
            showLogin();
        }
    };

    const showLogin = () => {
        elements.loginView.classList.remove('hidden');
        elements.dashboardView.classList.add('hidden');
    };

    const showDashboard = () => {
        elements.loginView.classList.add('hidden');
        elements.dashboardView.classList.remove('hidden');
        lucide.createIcons();
        renderPage('dashboard');
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        elements.loginError.classList.add('hidden');
        const email = elements.loginForm.email.value;
        const password = elements.loginForm.password.value;

        if (email === 'admin@bigwang.com' && password === 'admin123') {
            localStorage.setItem('adminAuthToken', 'mock-token-for-admin');
            showDashboard();
        } else {
            elements.loginError.textContent = 'Invalid credentials.';
            elements.loginError.classList.remove('hidden');
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('adminAuthToken');
        showLogin();
    };

    const handleNavigation = (e) => {
        e.preventDefault();
        const link = e.currentTarget;
        const pageId = link.dataset.page;

        elements.navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        
        renderPage(pageId);
    };

    const openModal = (title, bodyHtml, footerHtml = '') => {
        elements.modalTitle.textContent = title;
        elements.modalBody.innerHTML = bodyHtml;
        elements.modalFooter.innerHTML = footerHtml;
        elements.modal.classList.remove('hidden');
        elements.modalBackdrop.classList.remove('hidden');
        lucide.createIcons();
    };

    const closeModal = () => {
        elements.modal.classList.add('hidden');
        elements.modalBackdrop.classList.add('hidden');
        elements.modalBody.innerHTML = '';
        elements.modalFooter.innerHTML = '';
    };

    const API_BASE_URL = '/api/admin';

    const apiRequest = async (resource, method = 'GET', id = null, data = null, query = '') => {
        const url = `${API_BASE_URL}/${resource}${id ? `/${id}` : ''}${query}`;
        const token = localStorage.getItem('adminAuthToken');

        const options = {
            method,
            headers: {}
        };
        
        if (token) {
            options.headers['Authorization'] = `Bearer ${token}`;
        }

        if (data && (method === 'POST' || method === 'PUT')) {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(url, options);

            if (response.status === 204) {
                return { success: true };
            }
            
            const responseData = await response.json();

            if (!response.ok) {
                const errorMessage = responseData.message || response.statusText;
                console.error(`API Error: ${response.status} ${errorMessage} for URL: ${url}`);
                throw new Error(`API request failed: ${errorMessage}`);
            }

            return responseData;
        } catch (error) {
            console.error(`API Call failed: ${method} ${url}`, error);
            alert(`An error occurred while communicating with the server: ${error.message}. Please check the console for details.`);
            throw error;
        }
    };
    
    const renderUserManagement = async () => {
        state.currentFilters = {};
        elements.pageContent.innerHTML = `
            <div class=\"bg-white p-6 rounded-lg shadow-md\">\n                <div class=\"search-filter-bar\">\n                    <div class=\"relative flex-grow\">\n                        <input type=\"text\" id=\"user-search\" placeholder=\"Search users by name or email...\" class=\"w-full pl-10 pr-4 py-2 border rounded-lg\">\n                        <div class=\"absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none\">\n                            <i data-lucide=\"search\" class=\"w-5 h-5 text-gray-400\"></i>\n                        </div>\n                    </div>\n                    <select id=\"user-status-filter\" class=\"border rounded-lg py-2\">\n                        <option value=\"\">All Statuses</option>\n                        <option value=\"active\">Active</option>\n                        <option value=\"suspended\">Suspended</option>\n                    </select>\n                    <button id=\"add-user-btn\" class=\"flex items-center justify-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700\">\n                        <i data-lucide=\"plus\" class=\"w-5 h-5 mr-2\"></i> Add User\n                    </button>\n                </div>\n                <div class=\"overflow-x-auto\">\n                    <table class=\"management-table\">\n                        <thead><tr><th>Username</th><th>Email</th><th>Status</th><th>Created At</th><th class=\"text-right\">Actions</th></tr></thead>\n                        <tbody id=\"user-table-body\"></tbody>\n                    </table>\n                </div>\n            </div>`;
        lucide.createIcons();

        const tableBody = document.getElementById('user-table-body');
        const searchInput = document.getElementById('user-search');
        const statusFilter = document.getElementById('user-status-filter');

        const fetchAndDisplayUsers = async () => {
            const query = new URLSearchParams(state.currentFilters).toString();
            try {
                const users = await apiRequest('users', 'GET', null, null, query ? `?${query}` : '');
                tableBody.innerHTML = users.map(user => `
                    <tr id=\"user-row-${user.id}\">\n                        <td class=\"px-6 py-4 font-medium text-gray-900 whitespace-nowrap\">${user.username}</td>\n                        <td class=\"px-6 py-4\">${user.email}</td>\n                        <td class=\"px-6 py-4\"><span class=\"badge ${user.status === 'active' ? 'badge-green' : 'badge-red'}\">${user.status}</span></td>\n                        <td class=\"px-6 py-4\">${new Date(user.createdAt).toLocaleDateString()}</td>\n                        <td class=\"px-6 py-4 text-right\">\n                            <button data-action=\"edit\" data-id=\"${user.id}\" class=\"font-medium text-blue-600 hover:underline mr-4\">Edit</button>\n                            <button data-action=\"delete\" data-id=\"${user.id}\" class=\"font-medium text-red-600 hover:underline\">Delete</button>\n                        </td>\n                    </tr>\n                `).join('');
            } catch(error) {
                tableBody.innerHTML = `<tr><td colspan="5" class="text-center py-4 text-red-500">Failed to load users.</td></tr>`;
            }
        };

        const handleTableClick = (e) => {
            const action = e.target.dataset.action;
            const id = e.target.dataset.id;
            if (!action || !id) return;

            if (action === 'edit') handleUserEdit(id);
            if (action === 'delete') handleUserDelete(id);
        };
        
        const handleUserEdit = async (id) => {
            const user = id ? await apiRequest('users', 'GET', id) : { username: '', email: '', status: 'active' };
            if(!user && id) { alert('User not found!'); return; }
            
            const title = id ? 'Edit User' : 'Add User';
            const body = `
                <form id=\"user-form\" data-id=\"${id || ''}\" class=\"space-y-4\">\n                    <div>\n                        <label for=\"username\" class=\"block text-sm font-medium text-gray-700\">Username</label>\n                        <input type=\"text\" name=\"username\" value=\"${user.username}\" required class=\"mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500\">\n                    </div>\n                    <div>\n                        <label for=\"email\" class=\"block text-sm font-medium text-gray-700\">Email</label>\n                        <input type=\"email\" name=\"email\" value=\"${user.email}\" required class=\"mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500\">\n                    </div>\n                    <div>\n                        <label for=\"status\" class=\"block text-sm font-medium text-gray-700\">Status</label>\n                        <select name=\"status\" class=\"mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500\">\n                            <option value=\"active\" ${user.status === 'active' ? 'selected' : ''}>Active</option>\n                            <option value=\"suspended\" ${user.status === 'suspended' ? 'selected' : ''}>Suspended</option>\n                        </select>\n                    </div>\n                </form>`;
            const footer = `
                <button id=\"modal-cancel\" class=\"px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300\">Cancel</button>\n                <button id=\"modal-save\" class=\"px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700\">Save Changes</button>`;
            
            openModal(title, body, footer);

            document.getElementById('modal-cancel').onclick = closeModal;
            document.getElementById('modal-save').onclick = async () => {
                const form = document.getElementById('user-form');
                const formData = new FormData(form);
                const data = Object.fromEntries(formData.entries());
                
                try {
                    if (id) {
                        await apiRequest('users', 'PUT', id, data);
                    } else {
                        await apiRequest('users', 'POST', null, data);
                    }
                    closeModal();
                    fetchAndDisplayUsers();
                } catch(error) {
                    
                }
            };
        };

        const handleUserDelete = (id) => {
            const body = `<p>Are you sure you want to delete this user? This action cannot be undone.</p>`;
            const footer = `
                <button id=\"modal-cancel\" class=\"px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300\">Cancel</button>\n                <button id=\"modal-confirm-delete\" class=\"px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700\">Delete</button>`;
            openModal('Confirm Deletion', body, footer);

            document.getElementById('modal-cancel').onclick = closeModal;
            document.getElementById('modal-confirm-delete').onclick = async () => {
                try {
                    await apiRequest('users', 'DELETE', id);
                    closeModal();
                    fetchAndDisplayUsers();
                } catch (error) {

                }
            };
        };

        searchInput.oninput = () => { state.currentFilters.search = searchInput.value; fetchAndDisplayUsers(); };
        statusFilter.onchange = () => { state.currentFilters.status = statusFilter.value; fetchAndDisplayUsers(); };
        document.getElementById('add-user-btn').onclick = () => handleUserEdit(null);
        tableBody.addEventListener('click', handleTableClick);

        fetchAndDisplayUsers();
    };

    const renderPlatformManagement = () => {
        elements.pageContent.innerHTML = `
            <div class=\"bg-white p-6 rounded-lg shadow-md\">\n                <div class=\"border-b border-gray-200 mb-4\">\n                    <nav class=\"-mb-px flex space-x-4\" aria-label=\"Tabs\">\n                        <button data-tab=\"games\" class=\"tab-button active\">Games</button>\n                        <button data-tab=\"promotions\" class=\"tab-button\">Promotions</button>\n                    </nav>\n                </div>\n                <div id=\"platform-content\"></div>\n            </div>`;
        
        const renderTabContent = (tab) => {
            const platformContent = document.getElementById('platform-content');
            if (tab === 'games') {
                platformContent.innerHTML = '<div>Loading Games...</div>';
                renderGenericManager(platformContent, 'games', 'Game',\n                    ['Name', 'Category', 'Status', 'Release Date'],\n                    (item) => `
                        <td>${item.name}</td>\n                        <td>${item.category}</td>\n                        <td><span class=\"badge ${item.status === 'live' ? 'badge-green' : 'badge-yellow'}\">${item.status}</span></td>\n                        <td>${item.releaseDate}</td>`,\n                    (item) => `
                        <div class=\"space-y-4\">\n                            <input type=\"hidden\" name=\"id\" value=\"${item?.id || ''}\">\n                            <div><label class=\"block text-sm\">Name</label><input name=\"name\" value=\"${item?.name || ''}\" class=\"mt-1 block w-full border rounded-md p-2\"></div>\n                            <div><label class=\"block text-sm\">Category</label><input name=\"category\" value=\"${item?.category || ''}\" class=\"mt-1 block w-full border rounded-md p-2\"></div>\n                            <div><label class=\"block text-sm\">Status</label><select name=\"status\" class=\"mt-1 block w-full border rounded-md p-2\"><option value=\"live\" ${item?.status === 'live' ? 'selected' : ''}>Live</option><option value=\"maintenance\" ${item?.status === 'maintenance' ? 'selected' : ''}>Maintenance</option></select></div>\n                            <div><label class=\"block text-sm\">Release Date</label><input type=\"date\" name=\"releaseDate\" value=\"${item?.releaseDate || ''}\" class=\"mt-1 block w-full border rounded-md p-2\"></div>\n                        </div>`\n                );\n            } else if (tab === 'promotions') {\n                platformContent.innerHTML = '<div>Loading Promotions...</div>';\n                renderGenericManager(platformContent, 'promotions', 'Promotion',\n                    ['Title', 'Type', 'Status', 'Start Date', 'End Date'],\n                    (item) => `
                        <td>${item.title}</td>\n                        <td>${item.type}</td>\n                        <td><span class=\"badge ${item.status === 'active' ? 'badge-green' : item.status === 'expired' ? 'badge-gray' : 'badge-yellow'}\">${item.status}</span></td>\n                        <td>${item.startDate}</td>\n                        <td>${item.endDate}</td>`,\n                    (item) => `
                        <div class=\"space-y-4\">\n                            <input type=\"hidden\" name=\"id\" value=\"${item?.id || ''}\">\n                            <div><label class=\"block text-sm\">Title</label><input name=\"title\" value=\"${item?.title || ''}\" class=\"mt-1 block w-full border rounded-md p-2\"></div>\n                            <div><label class=\"block text-sm\">Type</label><input name=\"type\" value=\"${item?.type || ''}\" class=\"mt-1 block w-full border rounded-md p-2\"></div>\n                            <div><label class=\"block text-sm\">Status</label><select name=\"status\" class=\"mt-1 block w-full border rounded-md p-2\"><option value=\"active\" ${item?.status === 'active' ? 'selected' : ''}>Active</option><option value=\"inactive\" ${item?.status === 'inactive' ? 'selected' : ''}>Inactive</option><option value=\"expired\" ${item?.status === 'expired' ? 'selected' : ''}>Expired</option></select></div>\n                            <div><label class=\"block text-sm\">Start Date</label><input type=\"date\" name=\"startDate\" value=\"${item?.startDate || ''}\" class=\"mt-1 block w-full border rounded-md p-2\"></div>\n                            <div><label class=\"block text-sm\">End Date</label><input type=\"date\" name=\"endDate\" value=\"${item?.endDate || ''}\" class=\"mt-1 block w-full border rounded-md p-2\"></div>\n                        </div>`\n                );\n            }\n        };\n\n        document.querySelectorAll('.tab-button').forEach(button => {\n            button.addEventListener('click', (e) => {\n                document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));\n                e.currentTarget.classList.add('active');\n                renderTabContent(e.currentTarget.dataset.tab);\n            });\n        });\n\n        renderTabContent('games');\n    };\n\n    const renderGenericManager = async (container, resource, singular, headers, rowRenderer, formRenderer) => {\n        container.innerHTML = `\n            <div class=\"search-filter-bar\">\n                <div class=\"relative flex-grow\">\n                    <input type=\"text\" id=\"${resource}-search\" placeholder=\"Search ${resource}...\" class=\"w-full pl-10 pr-4 py-2 border rounded-lg\">\n                    <div class=\"absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none\">\n                        <i data-lucide=\"search\" class=\"w-5 h-5 text-gray-400\"></i>\n                    </div>\n                </div>\n                <button id=\"add-${singular.toLowerCase()}-btn\" class=\"flex items-center justify-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700\">\n                    <i data-lucide=\"plus\" class=\"w-5 h-5 mr-2\"></i> Add ${singular}\n                </button>\n            </div>\n            <div class=\"overflow-x-auto\">\n                <table class=\"management-table\">\n                    <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}<th class=\"text-right\">Actions</th></tr></thead>\n                    <tbody id=\"${resource}-table-body\"></tbody>\n                </table>\n            </div>`;\n        lucide.createIcons();\n    \n        const tableBody = document.getElementById(`${resource}-table-body`);\n        const searchInput = document.getElementById(`${resource}-search`);\n\n        const fetchAndDisplayItems = async (query = '') => {\n            try {\n                const items = await apiRequest(resource, 'GET', null, null, query);\n                tableBody.innerHTML = items.map(item => `\n                    <tr id=\"${resource}-row-${item.id}\">\n                        ${rowRenderer(item)}\n                        <td class=\"px-6 py-4 text-right\">\n                            <button data-action=\"edit\" data-id=\"${item.id}\" class=\"font-medium text-blue-600 hover:underline mr-4\">Edit</button>\n                            <button data-action=\"delete\" data-id=\"${item.id}\" class=\"font-medium text-red-600 hover:underline\">Delete</button>\n                        </td>\n                    </tr>\n                `).join('');\n            } catch(error) {\n                tableBody.innerHTML = `<tr><td colspan="${headers.length + 1}" class="text-center py-4 text-red-500">Failed to load ${resource}.</td></tr>`;\n            }\n        };\n    \n        const handleEdit = async (id) => {\n            const item = id ? await apiRequest(resource, 'GET', id) : null;\n            const title = id ? `Edit ${singular}` : `Add ${singular}`;\n            const body = `<form id=\"${resource}-form\" class=\"space-y-4\">${formRenderer(item)}</form>`;\n            const footer = `\n                <button id=\"modal-cancel\" class=\"px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300\">Cancel</button>\n                <button id=\"modal-save\" class=\"px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700\">Save</button>`;\n            \n            openModal(title, body, footer);\n\n            document.getElementById('modal-cancel').onclick = closeModal;\n            document.getElementById('modal-save').onclick = async () => {\n                const form = document.getElementById(`${resource}-form`);\n                const formData = new FormData(form);\n                const data = Object.fromEntries(formData.entries());\n                const method = id ? 'PUT' : 'POST';\n                const resourceId = id || null;\n                try {\n                    await apiRequest(resource, method, resourceId, data);\n                    closeModal();\n                    fetchAndDisplayItems();\n                } catch (error) {}\n            };\n        };\n\n        const handleDelete = (id) => {\n            openModal(`Delete ${singular}`, `<p>Are you sure you want to delete this ${singular.toLowerCase()}?</p>`, `\n                <button id=\"modal-cancel\" class=\"px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300\">Cancel</button>\n                <button id=\"modal-confirm-delete\" class=\"px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700\">Delete</button>`);\n            \n            document.getElementById('modal-cancel').onclick = closeModal;\n            document.getElementById('modal-confirm-delete').onclick = async () => {\n                try {\n                    await apiRequest(resource, 'DELETE', id);\n                    closeModal();\n                    fetchAndDisplayItems();\n                } catch (error) {}\n            };\n        };\n\n        searchInput.oninput = () => fetchAndDisplayItems(`?search=${searchInput.value}`);\n        document.getElementById(`add-${singular.toLowerCase()}-btn`).onclick = () => handleEdit(null);\n        tableBody.addEventListener('click', (e) => {\n            const action = e.target.dataset.action;\n            const id = e.target.dataset.id;\n            if (!action || !id) return;\n            if (action === 'edit') handleEdit(id);\n            if (action === 'delete') handleDelete(id);\n        });\n\n        fetchAndDisplayItems();\n    };\n\n\n    const renderPage = (pageId) => {\n        const pageTitles = {\n            'dashboard': 'Dashboard',\n            'user-management': 'User Management',\n            'platform-management': 'Platform Management',\n            'cashier-payments': 'Cashier & Payments'\n        };\n\n        elements.pageTitle.textContent = pageTitles[pageId] || 'Dashboard';\n        elements.pageContent.innerHTML = '';\n\n        switch (pageId) {\n            case 'dashboard':\n                renderDashboard();\n                break;\n            case 'user-management':\n                renderUserManagement();\n                break;\n            case 'platform-management':\n                renderPlatformManagement();\n                break;\n            case 'cashier-payments':\n                elements.pageContent.innerHTML = `<div class=\"bg-white p-6 rounded-lg shadow-md\"><h2 class=\"text-xl font-semibold\">Cashier & Payments</h2><p class=\"mt-2 text-gray-600\">Tools for managing user deposits, withdrawals, and transactions will be here.</p></div>`;\n                break;\n            default:\n                renderDashboard();\n        }\n        lucide.createIcons();\n    };\n\n    const renderDashboard = () => {\n        elements.pageContent.innerHTML = `\n            <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6\">\n                ${createKpiCard('Total Users', '1,428', 'users', 'bg-blue-100 text-blue-600')}\n                ${createKpiCard('Total Deposits (24h)', '$12,540', 'arrow-down-circle', 'bg-green-100 text-green-600')}\n                ${createKpiCard('Active Sessions', '312', 'activity', 'bg-yellow-100 text-yellow-600')}\n                ${createKpiCard('Tickets Pending', '17', 'alert-circle', 'bg-red-100 text-red-600')}\n            </div>\n            <div class=\"mt-8 bg-white p-6 rounded-lg shadow-md\">\n                <h2 class=\"text-xl font-semibold\">Recent Activity</h2>\n                <p class=\"mt-2 text-gray-600\">A live feed of platform activity will appear here.</p>\n            </div>\n        `;\n    };\n\n    const createKpiCard = (title, value, icon, colorClasses) => {\n        return `\n            <div class=\"kpi-card\">\n                <div class=\"icon-wrapper ${colorClasses}\">\n                    <i data-lucide=\"${icon}\" class=\"w-6 h-6\"></i>\n                </div>\n                <div>\n                    <p class=\"text-sm font-medium text-gray-500\">${title}</p>\n                    <p class=\"text-2xl font-semibold text-gray-800\">${value}</p>\n                </div>\n            </div>\n        `;\n    };\n\n    elements.loginForm.addEventListener('submit', handleLogin);\n    elements.logoutBtn.addEventListener('click', handleLogout);\n    elements.navLinks.forEach(link => {\n        if (!link.id.includes('logout')) {\n            link.addEventListener('click', handleNavigation);\n        }\n    });\n    elements.modalCloseBtn.addEventListener('click', closeModal);\n    elements.modalBackdrop.addEventListener('click', closeModal);\n\n    checkAuth();\n}\n```

